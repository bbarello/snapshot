const billingPageData = [
  {
    id: '30S6ZT2A',
    date: '2019-10-9',
    paymentMethod: 'MasterCard ending in 1234',
    price: '$7.00',
    btn: 'icon',
  },
  {
    id: '30S6ZT2A',
    date: '2019-10-9',
    paymentMethod: 'MasterCard ending in 1234',
    price: '$7.00',
    btn: 'icon',
  },
  {
    id: '30S6ZT2A',
    date: '2019-10-9',
    paymentMethod: 'MasterCard ending in 1234',
    price: '$7.00',
    btn: 'icon',
  },
  {
    id: '30S6ZT2A',
    date: '2019-10-9',
    paymentMethod: 'MasterCard ending in 1234',
    price: '$7.00',
    btn: 'icon',
  },
  {
    id: '30S6ZT2A',
    date: '2019-10-9',
    paymentMethod: 'MasterCard ending in 1234',
    price: '$7.00',
    btn: 'icon',
  },
  {
    id: '30S6ZT2A',
    date: '2019-10-9',
    paymentMethod: 'MasterCard ending in 1234',
    price: '$7.00',
    btn: 'icon',
  },
  {
    id: '30S6ZT2A',
    date: '2019-10-9',
    paymentMethod: 'MasterCard ending in 1234',
    price: '$7.00',
    btn: 'icon',
  },
  {
    id: '30S6ZT2A',
    date: '2019-10-9',
    paymentMethod: 'MasterCard ending in 1234',
    price: '$7.00',
    btn: 'icon',
  },
  {
    id: '30S6ZT2A',
    date: '2019-10-9',
    paymentMethod: 'MasterCard ending in 1234',
    price: '$7.00',
    btn: 'icon',
  },
];

export default billingPageData;
